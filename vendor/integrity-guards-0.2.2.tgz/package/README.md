# @saadmanhuq-code/integrity-guards

Cross-product integrity-guard toolkit for money/compliance products. Provides
importable, well-typed TypeScript functions that detect silent-failure classes
that green unit tests and code-reading audits can miss.

**Not published.** Internal test harness — wire into each product's test suite.

## Why

Wiring gaps (handler with no caller, field not passed to screener, task not
scheduled) survive green unit tests because unit tests check component
correctness, never *reachability*. This package provides guards that hunt
absence: they verify end-to-end wiring, not presence.

Every guard ships with an **anti-vacuous known-bad test**: a fixture the guard
MUST detect. The test FAILS if the guard does not catch the planted defect.
This is the analog of the conformance package's `collisions > 0` assertion.

## Guards

| # | Function | Detects |
|---|----------|---------|
| 1 | `bootCompositionGuard` | Unwired capabilities in the registry at app start |
| 2 | `assertNoOrphanHandlers` | Must-be-wired symbols with zero non-test callers |
| 3 | `runLifecycleSuite` | Capabilities that fire but produce zero side-effects |
| 4 | `assertReadinessLedger` | Invariants with no exact-matching passing test |
| 5 | `assertNoFloatMoney` | Float literals and parseFloat() on money paths |
| 6 | `assertRequiredEnv` | Required env vars missing at boot |
| 7 | `assertFailClosed` | Handlers that allow when a dependency is broken |
| 8 | `assertLedgerBalanced` | Debit/credit imbalance in double-entry ledger |
| 9 | `assertNoDeadStates` | FSM states that can be entered but never exited |
| 10 | `assertAuthCoverage` | Mutation routes without auth middleware |
| 11 | `assertAuditTrailCoverage` | Mutations that produce zero audit log entries |

## NOT provided — use mature tools instead

**Orphaned-module detection (#11):** Finding unused files/exports requires full
AST resolution across the import graph. Hand-rolling this produces systematic
false negatives (re-exports, dynamic imports, barrel files). Use
[**knip**](https://knip.dev/) instead — it handles all of these correctly.

```sh
npx knip           # reports unused files, exports, and dependencies
```

**Circular-import detection (#14):** Tracing cycles in the import graph
requires building the full dependency graph. Use
[**madge**](https://github.com/pahen/madge) or
[**import-linter**](https://import-linter.readthedocs.io/) instead.

```sh
npx madge --circular src/
```

A thin shell wrapper is provided if `knip` is on `PATH`:

```ts
import { spawnSync } from 'node:child_process';
if (process.env['CI']) {
  const r = spawnSync('knip', ['--reporter', 'json'], { encoding: 'utf-8' });
  if (r.status !== 0) throw new Error('knip found unused exports/files');
}
```

## Anti-vacuous pattern

Each guard test has two parts:

1. A **positive test** — known-good input passes.
2. An **anti-vacuous test** — a known-BAD fixture is planted; the test asserts
   the guard threw AND that the error message names the specific planted defect.

A guard that throws "directory not found" would masquerade as detection. The
anti-vacuous test prevents this by asserting on the defect name.

## `assertNoOrphanHandlers` — heuristic limitation

This guard uses regex-based reference detection, not AST import resolution.
Handlers registered via decorators (`@app.post(…)`, `@Injectable()`) or via
string keys in a DI container config file are counted as **reached** if the
handler name appears in any non-defining, non-test file — including the router
config or bootstrap file.

**Limitation:** a handler whose name appears *only* in its own defining file
and in test files will be flagged as orphaned, even if it is registered via a
decorator in that same file and dynamically dispatched. In that case, add a
reference in the router config or module registration file that the scanner can
find, or document the handler as framework-dispatched and exclude it from the
manifest.

For full accuracy, use knip (dead export) or a language-server-aware tool.

## `assertReadinessLedger` — exact test id matching

The `enforcing_test` field must be the **full test id** as it appears in the
JSON test report. Substring matching is intentionally not supported — a test id
of `test_pay` does NOT prove invariant `enforcing_test: test_payment_idempotency`.

Test id format depends on your runner:
- **vitest/jest:** `fullName` field in the assertion result (e.g.
  `"Suite > test name"`)
- **pytest-json-report:** `nodeid` (e.g.
  `"tests/test_payment.py::test_payment_idempotency"`)

## Run

```sh
pnpm --filter @saadmanhuq-code/integrity-guards test
```

## Wire into a product

```ts
import { bootCompositionGuard, assertNoOrphanHandlers } from '@saadmanhuq-code/integrity-guards';

// In your product's test suite (not in app boot code):
test('all payment capabilities are wired', () => {
  bootCompositionGuard(
    PAYMENT_CAPABILITY_REGISTRY,
    (cap) => wiredHandlers.has(cap.id),
    { getId: (c) => c.id, getName: (c) => c.name }
  );
});
```
